
# dpkt

The dpkt project is a python module for fast, simple packet parsing, with definitions for the basic TCP/IP protocols.

### Installation
```
pip install dpkt
```

.. toctree::
   :maxdepth: 2

   print_packets.md
   print_icmp.md
   print_http_requests.md

   changelog.md
   authors.md
   contributing.md
   plans.md
   admin_notes.md

   license.md

## About
This code is based on [dpkt code](https://code.google.com/p/dpkt/) lead by Dug Song and is now being maintained and improved by an extended set of [developers](https://github.com/kbandla/dpkt/graphs/contributors).

## LICENSE

BSD 3-Clause
